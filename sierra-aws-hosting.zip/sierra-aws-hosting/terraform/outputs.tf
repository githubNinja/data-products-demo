output "site_url" {
  description = "Your vanity URL."
  value       = "https://${var.domain_name}"
}

output "cloudfront_domain_name" {
  description = "Raw CloudFront domain (useful for testing before DNS propagates)."
  value       = aws_cloudfront_distribution.site.domain_name
}

output "cloudfront_distribution_id" {
  description = "Set as the GitHub Actions variable CLOUDFRONT_DISTRIBUTION_ID."
  value       = aws_cloudfront_distribution.site.id
}

output "s3_bucket_name" {
  description = "Set as the GitHub Actions variable S3_BUCKET."
  value       = aws_s3_bucket.site.id
}

output "github_deploy_role_arn" {
  description = "Set as the GitHub Actions secret AWS_DEPLOY_ROLE_ARN."
  value       = aws_iam_role.github_deploy.arn
}
