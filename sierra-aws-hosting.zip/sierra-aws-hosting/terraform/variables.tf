variable "domain_name" {
  description = "Vanity URL for the wiki, e.g. dataproducts.yourcompany.com"
  type        = string
}

variable "hosted_zone_id" {
  description = "Route 53 hosted zone ID for the parent domain. Required only if create_route53_records = true."
  type        = string
  default     = ""
}

variable "create_route53_records" {
  description = "Set false if DNS is managed outside Route 53 (then create the ACM validation + alias/CNAME records at your DNS provider)."
  type        = bool
  default     = true
}

variable "bucket_name" {
  description = "Globally unique S3 bucket name for the site files."
  type        = string
}

variable "aws_region" {
  description = "Region for the S3 bucket. CloudFront is global and its certificate is always in us-east-1."
  type        = string
  default     = "us-east-1"
}

variable "github_repo" {
  description = "GitHub repo allowed to deploy, in owner/name form, e.g. your-org/data-products. Deployment is locked to the main branch."
  type        = string
}
